# Preview Videos Folder

This folder contains preview videos for preset packs.

## Structure:
- `mm.mp4` - MusicMedia Effects & Text preview
- `bolt.mp4` - Bolt Motivation Effects & Text preview (when available)
- `futbol.mp4` - Futbol Media Effects & Text preview (when available)

## Guidelines:
- Use .mp4 format for best compatibility
- Recommended resolution: 1920x1080 or 1280x720
- Keep file sizes reasonable for web loading (under 50MB)
- Use descriptive filenames matching the preset names