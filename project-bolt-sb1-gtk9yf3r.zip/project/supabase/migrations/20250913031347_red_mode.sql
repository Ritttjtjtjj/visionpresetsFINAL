/*
  # Create custom_preset_requests table

  1. New Tables
    - `custom_preset_requests`
      - `id` (uuid, primary key)
      - `discord` (text, required) - Discord username
      - `email` (text, required) - Email address
      - `channel_link` (text, required) - YouTube/channel link to recreate
      - `details` (text, optional) - Additional details about the request
      - `created_at` (timestamptz) - When the request was created

  2. Security
    - Enable RLS on `custom_preset_requests` table
    - Add policy for anyone to insert requests (public submissions)
    - Add policy for authenticated users to read all requests (admin access)
*/

CREATE TABLE IF NOT EXISTS custom_preset_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  discord text NOT NULL,
  email text NOT NULL,
  channel_link text NOT NULL,
  details text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE custom_preset_requests ENABLE ROW LEVEL SECURITY;

-- Allow anyone to submit custom preset requests
CREATE POLICY "Anyone can submit custom preset requests"
  ON custom_preset_requests
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Allow authenticated users to read all requests (for admin purposes)
CREATE POLICY "Authenticated users can read all requests"
  ON custom_preset_requests
  FOR SELECT
  TO authenticated
  USING (true);