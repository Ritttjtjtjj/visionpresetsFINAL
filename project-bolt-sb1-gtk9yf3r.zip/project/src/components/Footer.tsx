import React from 'react';
import { Camera, Twitter, Instagram, Youtube, Mail } from 'lucide-react';
import ScrollAnimation from './ScrollAnimation';

const Footer = () => {
  return (
    <footer className="bg-bg-primary border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <ScrollAnimation>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center">
              <h3 className="text-2xl font-bold text-text-primary">
                <span className="text-orange-500 glow-text">V</span>ision
              </h3>
            </div>
            <p className="text-text-secondary">
              The world's largest marketplace for premium editing presets and creative tools.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">
                <Youtube className="w-5 h-5" />
              </a>
              <a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          {/* Marketplace */}
          <div>
            <h4 className="text-text-primary font-semibold mb-4">Marketplace</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">Browse Presets</a></li>
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">Categories</a></li>
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">Trending</a></li>
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">New Releases</a></li>
            </ul>
          </div>
          
          {/* Creators */}
          <div>
            <h4 className="text-text-primary font-semibold mb-4">Creators</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">Become a Creator</a></li>
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">Creator Guidelines</a></li>
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">Earnings</a></li>
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">Resources</a></li>
            </ul>
          </div>
          
          {/* Support */}
          <div>
            <h4 className="text-text-primary font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">Help Center</a></li>
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">Contact Us</a></li>
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">Terms of Service</a></li>
              <li><a href="#" className="text-text-secondary hover:text-orange-500 transition-colors duration-200">Privacy Policy</a></li>
            </ul>
          </div>
        </div>
        </ScrollAnimation>
        
      </div>
    </footer>
  );
};

export default Footer;