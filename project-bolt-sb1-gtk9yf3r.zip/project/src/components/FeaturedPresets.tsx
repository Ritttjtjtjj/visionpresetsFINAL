import React from 'react';
import { useState } from 'react';
import ScrollAnimation from './ScrollAnimation';
import { motion } from 'framer-motion';
import { Sparkles, ShoppingCart, Crown, Clock, Search } from 'lucide-react';
import CheckoutModal from './CheckoutModal';

const featuredPresets = [
  {
    title: 'MusicMedia Effects & Text',
    price: '$29',
    image: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=400',
    preview: 'https://youtube.com/shorts/wo9p_Hj2PoI',
    isYouTube: true,
    description: [
      'Text Animation And Glow',
      'Flashes',
      'Tints',
      'Fades',
      'Color Correction',
      'And More!'
    ],
  },
  {
    title: 'Bolt Motivation Effects & Text',
    price: 'Coming Soon',
    image: 'https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=400',
    comingSoon: true,
    description: [
      'Motivational Text Effects',
      'Dynamic Transitions',
      'Energy Boosts',
      'Inspiring Overlays',
      'Power Glows',
      'Success Animations'
    ],
  },
  {
    title: 'Futbol Media Effects & Text',
    price: 'Coming Soon',
    image: 'https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg?auto=compress&cs=tinysrgb&w=400',
    comingSoon: true,
    description: [
      'Soccer Text Effects',
      'Stadium Atmospheres',
      'Goal Celebrations',
      'Team Colors',
      'Match Graphics',
      'Victory Animations'
    ],
  },
];

const premiumPack = {
  title: 'Get it All',
  subtitle: 'Vision Premium',
  price: '$49/mo',
  image: 'https://images.pexels.com/photos/3945313/pexels-photo-3945313.jpeg?auto=compress&cs=tinysrgb&w=400',
  description: [
    'Bolt Motivation Pack',
    'MusicMedia Pack',
    'Futbol Media Pack',
    'All New Packs (Monthly)',
    'Updated Effects Library',
    'Priority Customer Support',
    'Exclusive Premium Content',
    'Early Access to New Releases',
    'Advanced Color Correction Tools'
  ],
};

interface FeaturedPresetsProps {
  searchQuery?: string;
}

const FeaturedPresets: React.FC<FeaturedPresetsProps> = ({ searchQuery = '' }) => {
  const [checkoutPreset, setCheckoutPreset] = useState<any>(null);

  const filteredPresets = featuredPresets.filter(preset =>
    preset.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    preset.description?.some(desc => desc.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handlePremiumPurchase = () => {
    window.open('https://whop.com/vision-9936/vision-premium-82/', '_blank');
  };

  const PresetSection = ({ preset, index }: { preset: any; index: number }) => {
    const isEven = index % 2 === 0;
    
    return (
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`grid grid-cols-1 lg:grid-cols-2 gap-24 items-center ${!isEven ? 'lg:grid-flow-col-dense' : ''}`}>
            {/* Preview */}
            <ScrollAnimation className={!isEven ? 'lg:col-start-2' : ''}>
              <div className="relative max-w-64 mx-auto">
                <div className="bg-bg-secondary border border-border rounded-xl overflow-hidden glow-border hover:shadow-glow hover:border-orange-500 transition-all duration-300 group">
                  <div className="relative overflow-hidden aspect-[9/16]">
                    {preset.comingSoon ? (
                      <div className="w-full h-full bg-gradient-to-br from-bg-tertiary to-bg-secondary flex items-center justify-center">
                        <div className="text-center">
                          <Clock className="w-12 h-12 text-orange-500 mx-auto mb-4" />
                          <p className="text-text-primary font-semibold text-lg">Coming Soon</p>
                          <p className="text-text-secondary text-sm mt-2">Stay tuned for updates</p>
                        </div>
                      </div>
                    ) : preset.isYouTube ? (
                      <iframe
                        src={`https://www.youtube.com/embed/${preset.preview.split('/').pop()}?autoplay=1&mute=1&loop=1&playlist=${preset.preview.split('/').pop()}&controls=0&showinfo=0&rel=0&modestbranding=1`}
                        className="w-full h-full group-hover:scale-110 transition-transform duration-500 ease-out"
                        frameBorder="0"
                        allow="autoplay; encrypted-media"
                        allowFullScreen
                      />
                    ) : preset.preview ? (
                      <video
                        autoPlay
                        muted
                        loop
                        playsInline
                        preload="auto"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 ease-out"
                        src={preset.preview}
                      >
                        Your browser does not support the video tag.
                      </video>
                    ) : (
                      <img
                        src={preset.image}
                        alt={preset.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 ease-out"
                      />
                    )}
                  </div>
                </div>
              </div>
            </ScrollAnimation>
            
            {/* Info */}
            <ScrollAnimation delay={0.2} className={!isEven ? 'lg:col-start-1' : ''}>
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl md:text-3xl font-bold text-text-primary mb-2">
                    {preset.title}
                  </h2>
                </div>
                
                {/* Features */}
                <div className="space-y-3">
                  <h3 className="text-lg font-semibold text-text-primary flex items-center">
                    <Sparkles className="w-4 h-4 text-orange-500 mr-2" />
                    What's Included
                  </h3>
                  <ul className="space-y-2">
                    {preset.description?.map((feature: string, index: number) => (
                      <li key={index} className="flex items-center text-text-primary">
                        <div className="w-1.5 h-1.5 bg-orange-500 rounded-full mr-3"></div>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Price and Buy Button */}
                <div className="space-y-3 pt-2">
                  <span className={`text-2xl font-bold block ${preset.comingSoon ? 'text-text-secondary' : 'text-orange-500 glow-text'}`}>
                    {preset.price}
                  </span>
                  {!preset.comingSoon && (
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        setCheckoutPreset(preset);
                      }}
                      className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 shadow-glow hover:shadow-glow-lg flex items-center"
                    >
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      View Options
                    </motion.button>
                  )}
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </div>
    );
  };

  const PremiumSection = () => {
    return (
      <div className="py-12 bg-gradient-to-br from-orange-500/10 to-orange-600/5 border-y border-orange-500/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            {/* Logo */}
            <ScrollAnimation>
              <div className="flex justify-center">
                <div className="w-64 h-64 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center shadow-glow-lg">
                  <h1 className="text-6xl font-bold text-white">
                    <span className="text-white">V</span>
                  </h1>
                </div>
              </div>
            </ScrollAnimation>
            
            {/* Info */}
            <ScrollAnimation delay={0.2}>
              <div className="space-y-6">
                <div>
                  <div className="flex items-center mb-2">
                    <Crown className="w-6 h-6 text-orange-500 mr-2" />
                    <span className="text-orange-500 font-semibold text-sm uppercase tracking-wide">Premium</span>
                  </div>
                  <h2 className="text-3xl md:text-4xl font-bold text-text-primary mb-2">
                    {premiumPack.title}
                  </h2>
                  <p className="text-text-secondary text-lg">Everything you need to create viral content</p>
                  <p className="text-orange-500 font-semibold text-sm mt-1">New Packs Every Month</p>
                </div>
                
                {/* Features */}
                <div className="space-y-3">
                  <h3 className="text-lg font-semibold text-text-primary flex items-center">
                    <Sparkles className="w-4 h-4 text-orange-500 mr-2" />
                    Complete Package Includes
                  </h3>
                  <ul className="space-y-2">
                    {premiumPack.description.map((feature: string, index: number) => (
                      <li key={index} className="flex items-center text-text-primary">
                        <div className="w-1.5 h-1.5 bg-orange-500 rounded-full mr-3"></div>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Price and Buy Button */}
                <div className="space-y-4 pt-2">
                  <div className="flex items-baseline space-x-2">
                    <span className="text-3xl font-bold text-orange-500 glow-text">{premiumPack.price}</span>
                    <span className="text-text-secondary">per month</span>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handlePremiumPurchase}
                    className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-300 shadow-glow hover:shadow-glow-lg flex items-center text-lg"
                  >
                    <Crown className="w-5 h-5 mr-2" />
                    Get Premium Access
                  </motion.button>
                  <p className="text-text-secondary text-sm">Cancel anytime • Instant access to all packs</p>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </div>
    );
  };

  return (
    <section id="featured-presets" className="bg-bg-primary py-8">
      {/* Premium Section */}
      <PremiumSection />
      
      {/* Divider */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="border-t border-border"></div>
      </div>
      
      {/* Filtered Presets */}
      {filteredPresets.length === 0 ? (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <p className="text-text-secondary text-lg">No presets found matching your search.</p>
        </div>
      ) : (
        filteredPresets.map((preset, index) => (
          <div key={preset.title}>
            <PresetSection preset={preset} index={index} />
            {index < filteredPresets.length - 1 && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="border-t border-border"></div>
              </div>
            )}
          </div>
        ))
      )}
      
      <CheckoutModal
        isOpen={!!checkoutPreset}
        onClose={() => setCheckoutPreset(null)}
        preset={checkoutPreset || featuredPresets[0]}
      />
    </section>
  );
};

export default FeaturedPresets;