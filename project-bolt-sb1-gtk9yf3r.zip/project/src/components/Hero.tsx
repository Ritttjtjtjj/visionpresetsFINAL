import React from 'react';
import { ArrowRight, Sparkles, TrendingUp, Star } from 'lucide-react';
import { motion } from 'framer-motion';
import ScrollAnimation from './ScrollAnimation';

const Hero = () => {
  return (
    <section className="bg-bg-primary pt-16 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <ScrollAnimation delay={0.1}>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-text-primary mb-6">
              <span className="text-orange-500 glow-text">Proven Viral Presets</span>
              <span className="block text-text-primary">One Click Away</span>
            </h1>
          </ScrollAnimation>
          
          <ScrollAnimation delay={0.2} className="flex flex-col sm:flex-row justify-center items-center gap-4 mb-12">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                const featuredSection = document.getElementById('featured-presets');
                featuredSection?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300 flex items-center group shadow-glow hover:shadow-glow-lg"
            >
              Explore Presets
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </motion.button>
          </ScrollAnimation>
          
          {/* Our Presets Section */}
          <ScrollAnimation delay={0.3}>
            <div className="mt-20">
              <h2 className="text-3xl font-bold text-text-primary mb-12">Our Presets</h2>
              <div className="flex justify-center items-center space-x-16">
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 bg-bg-secondary border border-border rounded-full flex items-center justify-center mb-4 hover:border-orange-500 transition-all duration-200 overflow-hidden">
                    <img src="/channel-logos/musicmedia.png" alt="MusicMedia" className="w-full h-full rounded-full object-cover" />
                  </div>
                  <span className="text-text-primary font-medium text-lg">MusicMedia</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 bg-bg-secondary border border-border rounded-full flex items-center justify-center mb-4 hover:border-orange-500 transition-all duration-200 overflow-hidden">
                    <img src="/channel-logos/bolt.png" alt="Bolt Motivation" className="w-full h-full rounded-full object-cover" />
                  </div>
                  <span className="text-text-primary font-medium text-lg">Bolt Motivation</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 bg-bg-secondary border border-border rounded-full flex items-center justify-center mb-4 hover:border-orange-500 transition-all duration-200 overflow-hidden">
                    <img src="/channel-logos/futbol.png" alt="Futbol Media" className="w-full h-full rounded-full object-cover" />
                  </div>
                  <span className="text-text-primary font-medium text-lg">Futbol Media</span>
                </div>
              </div>
            </div>
          </ScrollAnimation>
          
        </div>
      </div>
    </section>
  );
};

export default Hero;