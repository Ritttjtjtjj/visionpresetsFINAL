import React from 'react';
import { useState, useRef, useEffect } from 'react';
import { X } from 'lucide-react';
import { motion } from 'framer-motion';
import CheckoutModal from './CheckoutModal';

interface PresetCardProps {
  title: string;
  price: string;
  image: string;
  preview?: string;
  description?: string[];
}

const PresetCard: React.FC<PresetCardProps> = ({
  title,
  price,
  image,
  preview,
  description,
}) => {
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (preview && videoRef.current) {
      const video = videoRef.current;
      
      const handleLoadedData = () => {
        console.log('Video loaded, duration:', video.duration);
        video.currentTime = 0;
        video.play().catch(console.error);
      };

      const handleEnded = () => {
        console.log('Video ended, restarting');
        video.currentTime = 0;
        video.play().catch(console.error);
      };

      video.addEventListener('loadeddata', handleLoadedData);
      video.addEventListener('ended', handleEnded);

      return () => {
        video.removeEventListener('loadeddata', handleLoadedData);
        video.removeEventListener('ended', handleEnded);
      };
    }
  }, [preview]);

  return (
    <>
      <motion.div
        whileHover={{ y: -2 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className="bg-bg-secondary border border-border rounded-xl overflow-hidden hover:border-orange-500 transition-all duration-300 group glow-border hover:shadow-glow"
      >
      {/* Media */}
      <div className="relative aspect-square overflow-hidden">
        {preview ? (
          <video
            ref={videoRef}
            muted
            loop
            playsInline
            preload="auto"
            className="w-full h-full object-contain bg-black group-hover:scale-110 transition-transform duration-500 ease-out"
            src={preview}
          >
            Your browser does not support the video tag.
          </video>
        ) : (
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 ease-out"
          />
        )}
      </div>
      
      {/* Content */}
      <div className="p-4">
        <div className="mb-2">
          <h3 className="text-text-primary font-semibold text-lg mb-1 line-clamp-2">{title}</h3>
          {description && (
            <ul className="text-text-secondary text-sm space-y-1 mt-2">
              {description.map((item, index) => (
                <li key={index} className="flex items-center">
                  <span className="w-1 h-1 bg-orange-500 rounded-full mr-2"></span>
                  {item}
                </li>
              ))}
            </ul>
          )}
        </div>
        
        {/* Price & Add to Cart */}
        <div className="flex items-center justify-between mt-4">
          <span className="text-orange-500 text-xl font-bold glow-text">{price}</span>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setIsCheckoutOpen(true)}
            className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 shadow-glow hover:shadow-glow-lg"
          >
            Add to Cart
          </motion.button>
        </div>
      </div>
      </motion.div>
      
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        preset={{ title, price, image }}
      />
    </>
  );
};

export default PresetCard;