import React from 'react';
import { Camera, Video, Palette, Sun, Mountain, User } from 'lucide-react';

const categories = [
  { name: 'Photography', icon: Camera, count: '2.5K', color: 'text-orange-500' },
  { name: 'Video LUTs', icon: Video, count: '1.8K', color: 'text-orange-600' },
  { name: 'Lightroom', icon: Sun, count: '3.2K', color: 'text-yellow-500' },
  { name: 'Photoshop', icon: Palette, count: '1.2K', color: 'text-purple-500' },
  { name: 'Landscape', icon: Mountain, count: '980', color: 'text-green-500' },
  { name: 'Portrait', icon: User, count: '1.5K', color: 'text-pink-500' },
];

const Categories = () => {
  return (
    <section className="bg-bg-secondary py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-text-primary mb-4">
            Explore by Category
          </h2>
          <p className="text-text-secondary text-lg max-w-2xl mx-auto">
            Find the perfect presets for your creative style and project needs
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {categories.map((category) => (
            <div
              key={category.name}
              className="bg-bg-primary border border-border rounded-xl p-6 hover:border-orange-500 transition-all duration-300 cursor-pointer group glow-border hover:shadow-glow"
            >
              <div className="text-center">
                <category.icon className={`w-8 h-8 ${category.color} mx-auto mb-4 group-hover:scale-110 transition-transform duration-200`} />
                <h3 className="text-text-primary font-semibold mb-2">{category.name}</h3>
                <p className="text-text-secondary text-sm">{category.count} presets</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;