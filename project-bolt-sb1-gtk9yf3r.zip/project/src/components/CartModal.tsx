import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Trash2, ShoppingCart } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const CartModal: React.FC<CartModalProps> = ({ isOpen, onClose }) => {
  const { items, removeFromCart, clearCart, getTotal } = useCart();

  const handleCheckout = () => {
    if (items.length === 0) return;
    
    // For now, redirect to the first item's checkout
    // In a real app, you'd handle multiple items differently
    const firstItem = items[0];
    if (firstItem.title.includes('MusicMedia')) {
      if (firstItem.includeShakes) {
        window.open('https://whop.com/vision-9936/musicmedia-text-effects-shak/', '_blank');
      } else {
        window.open('https://whop.com/vision-9936/?a=kyx121', '_blank');
      }
    }
    clearCart();
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-bg-primary border border-border rounded-xl max-w-md w-full max-h-[80vh] overflow-hidden glow-border"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h2 className="text-xl font-bold text-text-primary flex items-center">
                <ShoppingCart className="w-5 h-5 mr-2" />
                Shopping Cart ({items.length})
              </h2>
              <button
                onClick={onClose}
                className="text-text-secondary hover:text-orange-500 transition-colors duration-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto max-h-96">
              {items.length === 0 ? (
                <div className="p-8 text-center">
                  <ShoppingCart className="w-12 h-12 text-text-muted mx-auto mb-4" />
                  <p className="text-text-secondary">Your cart is empty</p>
                </div>
              ) : (
                <div className="p-4 space-y-4">
                  {items.map((item) => (
                    <div key={`${item.id}-${item.includeShakes}`} className="flex items-center bg-bg-secondary rounded-lg p-3">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-12 h-12 object-cover rounded-lg mr-3"
                      />
                      <div className="flex-1">
                        <h3 className="text-text-primary font-medium text-sm">{item.title}</h3>
                        {item.includeShakes && (
                          <p className="text-orange-500 text-xs">+ Shakes Pack</p>
                        )}
                        <p className="text-orange-500 font-bold text-sm">
                          ${(parseFloat(item.price.replace('$', '')) + (item.includeShakes ? 4.99 : 0)).toFixed(2)}
                        </p>
                      </div>
                      <button
                        onClick={() => removeFromCart(`${item.id}-${item.includeShakes}`)}
                        className="text-text-secondary hover:text-red-500 transition-colors duration-200 p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {items.length > 0 && (
              <div className="border-t border-border p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-text-primary font-semibold">Total</span>
                  <span className="text-orange-500 font-bold text-lg glow-text">
                    ${getTotal().toFixed(2)}
                  </span>
                </div>
                <div className="flex space-x-3">
                  <button
                    onClick={clearCart}
                    className="flex-1 bg-bg-secondary border border-border text-text-secondary hover:text-text-primary py-2 rounded-lg font-medium transition-colors duration-200"
                  >
                    Clear Cart
                  </button>
                  <button
                    onClick={handleCheckout}
                    className="flex-1 bg-orange-500 hover:bg-orange-600 text-white py-2 rounded-lg font-medium transition-all duration-200 shadow-glow hover:shadow-glow-lg"
                  >
                    Checkout
                  </button>
                </div>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CartModal;