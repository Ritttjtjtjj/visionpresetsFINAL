import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Minus, ShoppingCart, Sparkles } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  preset: {
    title: string;
    price: string;
    image: string;
  };
}

const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose, preset }) => {
  const [includeShakes, setIncludeShakes] = useState(false);
  const { addToCart } = useCart();
  
  const basePrice = parseFloat(preset.price.replace('$', ''));
  const shakesPrice = 4.99;
  const total = basePrice + (includeShakes ? shakesPrice : 0);
  
  const shouldShowUpsell = preset.title.includes('MusicMedia') || preset.title.includes('Bolt');

  const handleAddToCart = () => {
    const cartItem = {
      id: preset.title.toLowerCase().replace(/\s+/g, '-'),
      title: preset.title,
      price: preset.price,
      image: preset.image,
      includeShakes: shouldShowUpsell ? includeShakes : false,
    };
    
    addToCart(cartItem);
    onClose();
  };

  const handlePurchase = () => {
    // Handle MusicMedia purchases with upsell logic
    if (preset.title.includes('MusicMedia')) {
      if (includeShakes) {
        // Redirect to MusicMedia + Shakes bundle
        window.open('https://whop.com/vision-9936/musicmedia-text-effects-shak/', '_blank');
      } else {
        // Redirect to MusicMedia only
        window.open('https://whop.com/vision-9936/?a=kyx121', '_blank');
      }
    }
    // Close modal after redirect
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-bg-primary border border-border rounded-xl max-w-md w-full p-6 glow-border"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-text-primary">Checkout</h2>
              <button
                onClick={onClose}
                className="text-text-secondary hover:text-orange-500 transition-colors duration-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Product */}
            <div className="flex items-center mb-6">
              <img
                src={preset.image}
                alt={preset.title}
                className="w-16 h-16 object-cover rounded-lg mr-4"
              />
              <div className="flex-1">
                <h3 className="text-text-primary font-semibold">{preset.title}</h3>
                <p className="text-orange-500 font-bold">{preset.price}</p>
              </div>
            </div>


            {/* Upsell for MusicMedia and Bolt */}
            {shouldShowUpsell && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, ease: "easeOut" }}
                className="mb-6 p-4 bg-bg-secondary border border-orange-500/30 rounded-lg glow-border"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Sparkles className="w-5 h-5 text-orange-500 mr-2" />
                    <div>
                      <h4 className="text-text-primary font-semibold">Add Shakes Pack</h4>
                      <p className="text-text-secondary text-sm">Perfect complement to your effects</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <span className="text-orange-500 font-bold mr-3">+$4.99</span>
                    <button
                      onClick={() => setIncludeShakes(!includeShakes)}
                      className={`w-12 h-6 rounded-full transition-colors duration-200 relative ${
                        includeShakes ? 'bg-orange-500' : 'bg-bg-tertiary border border-border'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform duration-200 ${
                          includeShakes ? 'translate-x-6' : 'translate-x-0.5'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Total */}
            <div className="border-t border-border pt-4 mb-6">
              <div className="flex items-center justify-between text-lg">
                <span className="text-text-primary font-semibold">Total</span>
                <span className="text-orange-500 font-bold glow-text">${total.toFixed(2)}</span>
              </div>
            </div>

            {/* Checkout Button */}
            <div className="flex space-x-3">
              <button 
                onClick={handleAddToCart}
                className="flex-1 bg-bg-secondary border border-border text-text-primary hover:border-orange-500 py-3 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center"
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                Add to Cart
              </button>
              <button 
                onClick={handlePurchase}
                className="flex-1 bg-orange-500 hover:bg-orange-600 text-white py-3 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center shadow-glow hover:shadow-glow-lg"
              >
                Buy Now
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CheckoutModal;