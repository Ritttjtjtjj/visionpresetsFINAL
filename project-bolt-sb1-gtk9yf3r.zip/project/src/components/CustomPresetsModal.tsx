import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Palette, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase, CustomPresetRequest } from '../lib/supabase';

interface CustomPresetsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const CustomPresetsModal: React.FC<CustomPresetsModalProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    discord: '',
    email: '',
    channelLink: '',
    details: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');
    setErrorMessage('');
    
    try {
      if (!supabase) {
        throw new Error('Supabase is not configured. Please set up your environment variables.');
      }

      const requestData: Omit<CustomPresetRequest, 'id' | 'created_at'> = {
        discord: formData.discord,
        email: formData.email,
        channel_link: formData.channelLink,
        details: formData.details || null
      };

      const { error } = await supabase
        .from('custom_preset_requests')
        .insert([requestData]);

      if (error) {
        throw error;
      }

      setSubmitStatus('success');
      setFormData({ discord: '', email: '', channelLink: '', details: '' });
      
      // Close modal after 2 seconds
      setTimeout(() => {
        onClose();
        setSubmitStatus('idle');
      }, 2000);
      
    } catch (error: any) {
      console.error('Error submitting custom preset request:', error);
      setSubmitStatus('error');
      setErrorMessage(error.message || 'Failed to submit request. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-bg-primary border border-border rounded-xl max-w-md w-full p-6 glow-border max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center">
                <Palette className="w-6 h-6 text-orange-500 mr-2" />
                <h2 className="text-xl font-bold text-text-primary">Custom Presets</h2>
              </div>
              <button
                onClick={onClose}
                className="text-text-secondary hover:text-orange-500 transition-colors duration-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Description */}
            <div className="mb-6">
              <p className="text-text-secondary text-sm">
                Want us to recreate a specific style or effect? Fill out the form below and we'll create custom presets just for you!
              </p>
            </div>

            {/* Status Messages */}
            {submitStatus === 'success' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mb-6 p-4 bg-green-500/10 border border-green-500/30 rounded-lg flex items-center"
              >
                <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                <p className="text-green-500 text-sm">Request submitted successfully! We'll get back to you soon.</p>
              </motion.div>
            )}

            {submitStatus === 'error' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-lg flex items-center"
              >
                <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
                <p className="text-red-500 text-sm">{errorMessage}</p>
              </motion.div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4" style={{ display: submitStatus === 'success' ? 'none' : 'block' }}>
              {/* Discord */}
              <div>
                <label htmlFor="discord" className="block text-text-primary font-medium mb-2">
                  Discord Username *
                </label>
                <input
                  type="text"
                  id="discord"
                  name="discord"
                  value={formData.discord}
                  onChange={handleInputChange}
                  required
                  placeholder="username#1234"
                  className="w-full bg-bg-secondary border border-border rounded-lg px-3 py-2 text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all duration-200"
                />
              </div>

              {/* Email */}
              <div>
                <label htmlFor="email" className="block text-text-primary font-medium mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  placeholder="your@email.com"
                  className="w-full bg-bg-secondary border border-border rounded-lg px-3 py-2 text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all duration-200"
                />
              </div>

              {/* Channel Link */}
              <div>
                <label htmlFor="channelLink" className="block text-text-primary font-medium mb-2">
                  Channel/Video Link to Recreate *
                </label>
                <input
                  type="url"
                  id="channelLink"
                  name="channelLink"
                  value={formData.channelLink}
                  onChange={handleInputChange}
                  required
                  placeholder="https://youtube.com/..."
                  className="w-full bg-bg-secondary border border-border rounded-lg px-3 py-2 text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all duration-200"
                />
              </div>

              {/* Details */}
              <div>
                <label htmlFor="details" className="block text-text-primary font-medium mb-2">
                  Additional Details
                </label>
                <textarea
                  id="details"
                  name="details"
                  value={formData.details}
                  onChange={handleInputChange}
                  rows={4}
                  placeholder="Tell us more about what specific effects, styles, or elements you want us to recreate..."
                  className="w-full bg-bg-secondary border border-border rounded-lg px-3 py-2 text-text-primary placeholder-text-muted focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all duration-200 resize-none"
                />
              </div>

              {/* Submit Button */}
              <motion.button
                type="submit"
                disabled={isSubmitting}
                whileHover={{ scale: isSubmitting ? 1 : 1.02 }}
                whileTap={{ scale: isSubmitting ? 1 : 0.98 }}
                className={`w-full py-3 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center ${
                  isSubmitting 
                    ? 'bg-orange-400 cursor-not-allowed' 
                    : 'bg-orange-500 hover:bg-orange-600 shadow-glow hover:shadow-glow-lg'
                } text-white`}
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Submitting...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Submit Request
                  </>
                )}
              </motion.button>
            </form>

            {/* Footer Note */}
            <div className="mt-4 text-center">
              <p className="text-text-muted text-xs">
                We'll review your request and get back to you within 24-48 hours
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CustomPresetsModal;