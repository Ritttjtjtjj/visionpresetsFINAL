import React from 'react';
import { useState } from 'react';
import { CartProvider } from './contexts/CartContext';
import Header from './components/Header';
import Hero from './components/Hero';
import FeaturedPresets from './components/FeaturedPresets';
import Footer from './components/Footer';

function App() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <CartProvider>
      <div className="min-h-screen bg-bg-primary">
        <Header searchQuery={searchQuery} onSearchChange={setSearchQuery} />
        <Hero />
        <FeaturedPresets searchQuery={searchQuery} />
        <Footer />
      </div>
    </CartProvider>
  );
}

export default App;